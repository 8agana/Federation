import { LLMProvider, LLMResponse } from '../lib/api/types';
import { OpenAIProvider } from '../lib/api/openai';
import { AnthropicProvider } from '../lib/api/anthropic';
import { GeminiProvider } from '../lib/api/gemini';

// Mock API keys for testing
// In a real application, these would be provided by the user
const TEST_API_KEYS = {
  openai: process.env.TEST_OPENAI_API_KEY || 'sk-test-openai-key',
  anthropic: process.env.TEST_ANTHROPIC_API_KEY || 'sk-ant-test-anthropic-key',
  gemini: process.env.TEST_GEMINI_API_KEY || 'test-gemini-key'
};

describe('LLM Provider Tests', () => {
  let openaiProvider: LLMProvider;
  let anthropicProvider: LLMProvider;
  let geminiProvider: LLMProvider;
  
  beforeEach(() => {
    // Initialize providers with test API keys
    openaiProvider = new OpenAIProvider({ apiKey: TEST_API_KEYS.openai });
    anthropicProvider = new AnthropicProvider({ apiKey: TEST_API_KEYS.anthropic });
    geminiProvider = new GeminiProvider({ apiKey: TEST_API_KEYS.gemini });
    
    // Mock fetch for API calls
    global.fetch = jest.fn();
  });
  
  afterEach(() => {
    jest.resetAllMocks();
  });
  
  test('OpenAI provider should format requests correctly', async () => {
    // Mock successful response
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: async () => ({
        id: 'test-id',
        choices: [{ message: { content: 'Test response from OpenAI' } }],
        model: 'gpt-4o',
        usage: {
          prompt_tokens: 10,
          completion_tokens: 20,
          total_tokens: 30
        }
      })
    });
    
    // Call the provider
    await openaiProvider.sendMessage('Test message', 'test-conversation-id');
    
    // Check that fetch was called with the correct arguments
    expect(global.fetch).toHaveBeenCalledWith(
      'https://api.openai.com/v1/chat/completions',
      expect.objectContaining({
        method: 'POST',
        headers: expect.objectContaining({
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${TEST_API_KEYS.openai}`
        }),
        body: expect.stringContaining('Test message')
      })
    );
  });
  
  test('Anthropic provider should format requests correctly', async () => {
    // Mock successful response
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: async () => ({
        id: 'test-id',
        content: [{ text: 'Test response from Claude' }],
        model: 'claude-3-7-sonnet-20240229',
        usage: {
          input_tokens: 10,
          output_tokens: 20
        }
      })
    });
    
    // Call the provider
    await anthropicProvider.sendMessage('Test message', 'test-conversation-id');
    
    // Check that fetch was called with the correct arguments
    expect(global.fetch).toHaveBeenCalledWith(
      'https://api.anthropic.com/v1/messages',
      expect.objectContaining({
        method: 'POST',
        headers: expect.objectContaining({
          'Content-Type': 'application/json',
          'x-api-key': TEST_API_KEYS.anthropic,
          'anthropic-version': '2023-06-01'
        }),
        body: expect.stringContaining('Test message')
      })
    );
  });
  
  test('Gemini provider should format requests correctly', async () => {
    // Mock successful response
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: true,
      json: async () => ({
        candidates: [{
          content: {
            parts: [{ text: 'Test response from Gemini' }]
          }
        }]
      })
    });
    
    // Call the provider
    await geminiProvider.sendMessage('Test message', 'test-conversation-id');
    
    // Check that fetch was called with the correct arguments
    expect(global.fetch).toHaveBeenCalledWith(
      `https://generativelanguage.googleapis.com/v1/models/gemini-2.0-flash:generateContent?key=${TEST_API_KEYS.gemini}`,
      expect.objectContaining({
        method: 'POST',
        headers: expect.objectContaining({
          'Content-Type': 'application/json'
        }),
        body: expect.stringContaining('Test message')
      })
    );
  });
  
  test('Providers should handle API errors gracefully', async () => {
    // Mock error response
    (global.fetch as jest.Mock).mockResolvedValueOnce({
      ok: false,
      status: 401,
      statusText: 'Unauthorized',
      json: async () => ({
        error: {
          message: 'Invalid API key'
        }
      })
    });
    
    // Call the provider and expect it to throw
    await expect(openaiProvider.sendMessage('Test message', 'test-conversation-id'))
      .rejects.toThrow('OpenAI API error: Invalid API key');
  });
  
  test('Providers should return models', async () => {
    // Test that getModels returns an array of models
    const openaiModels = await openaiProvider.getModels();
    const anthropicModels = await anthropicProvider.getModels();
    const geminiModels = await geminiProvider.getModels();
    
    expect(Array.isArray(openaiModels)).toBe(true);
    expect(Array.isArray(anthropicModels)).toBe(true);
    expect(Array.isArray(geminiModels)).toBe(true);
    
    // Check that each model has the required properties
    const checkModel = (model: any) => {
      expect(model).toHaveProperty('id');
      expect(model).toHaveProperty('name');
      expect(model).toHaveProperty('provider');
      expect(model).toHaveProperty('capabilities');
    };
    
    openaiModels.forEach(checkModel);
    anthropicModels.forEach(checkModel);
    geminiModels.forEach(checkModel);
  });
});
