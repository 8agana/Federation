// Base interface for all LLM providers
export interface LLMProvider {
  sendMessage(message: string, conversationId: string): Promise<LLMResponse>;
  getModels(): Promise<Model[]>;
  getUsage(): Promise<UsageMetrics>;
}

// Response from an LLM
export interface LLMResponse {
  id: string;
  content: string;
  model: string;
  provider: 'openai' | 'anthropic' | 'gemini';
  usage: {
    promptTokens: number;
    completionTokens: number;
    totalTokens: number;
  };
}

// Model information
export interface Model {
  id: string;
  name: string;
  provider: 'openai' | 'anthropic' | 'gemini';
  capabilities: string[];
}

// Usage metrics
export interface UsageMetrics {
  totalTokens: number;
  totalCost: number;
  breakdown: {
    [provider: string]: {
      tokens: number;
      cost: number;
    };
  };
}

// Configuration for LLM providers
export interface LLMConfig {
  apiKey: string;
  maxTokens?: number;
  temperature?: number;
}
