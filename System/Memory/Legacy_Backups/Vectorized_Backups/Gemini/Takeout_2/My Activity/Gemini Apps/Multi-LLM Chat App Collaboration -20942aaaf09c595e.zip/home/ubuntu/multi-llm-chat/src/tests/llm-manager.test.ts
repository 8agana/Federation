import { LLMManager } from '@/lib/api';
import { OpenAIProvider } from '@/lib/api/openai';
import { AnthropicProvider } from '@/lib/api/anthropic';
import { GeminiProvider } from '@/lib/api/gemini';

// Mock the provider classes
jest.mock('@/lib/api/openai');
jest.mock('@/lib/api/anthropic');
jest.mock('@/lib/api/gemini');

describe('LLMManager', () => {
  beforeEach(() => {
    jest.clearAllMocks();
    
    // Set up mock implementations
    (OpenAIProvider as jest.Mock).mockImplementation(() => ({
      sendMessage: jest.fn().mockResolvedValue({
        id: 'openai-test-id',
        content: 'Test response from OpenAI',
        model: 'gpt-4o',
        provider: 'openai',
        usage: { promptTokens: 10, completionTokens: 20, totalTokens: 30 }
      })
    }));
    
    (AnthropicProvider as jest.Mock).mockImplementation(() => ({
      sendMessage: jest.fn().mockResolvedValue({
        id: 'anthropic-test-id',
        content: 'Test response from Claude',
        model: 'claude-3-7-sonnet-20240229',
        provider: 'anthropic',
        usage: { promptTokens: 10, completionTokens: 20, totalTokens: 30 }
      })
    }));
    
    (GeminiProvider as jest.Mock).mockImplementation(() => ({
      sendMessage: jest.fn().mockResolvedValue({
        id: 'gemini-test-id',
        content: 'Test response from Gemini',
        model: 'gemini-2.0-flash',
        provider: 'gemini',
        usage: { promptTokens: 10, completionTokens: 20, totalTokens: 30 }
      })
    }));
  });
  
  test('should initialize providers with configs', () => {
    const configs = {
      openai: { apiKey: 'test-openai-key' },
      anthropic: { apiKey: 'test-anthropic-key' },
      gemini: { apiKey: 'test-gemini-key' }
    };
    
    const manager = new LLMManager(configs);
    
    expect(OpenAIProvider).toHaveBeenCalledWith(configs.openai);
    expect(AnthropicProvider).toHaveBeenCalledWith(configs.anthropic);
    expect(GeminiProvider).toHaveBeenCalledWith(configs.gemini);
  });
  
  test('should add providers dynamically', () => {
    const manager = new LLMManager();
    
    manager.addProvider('openai', { apiKey: 'test-openai-key' });
    manager.addProvider('anthropic', { apiKey: 'test-anthropic-key' });
    
    expect(OpenAIProvider).toHaveBeenCalledWith({ apiKey: 'test-openai-key' });
    expect(AnthropicProvider).toHaveBeenCalledWith({ apiKey: 'test-anthropic-key' });
    expect(GeminiProvider).not.toHaveBeenCalled();
  });
  
  test('should check if provider exists', () => {
    const manager = new LLMManager();
    
    manager.addProvider('openai', { apiKey: 'test-openai-key' });
    
    expect(manager.hasProvider('openai')).toBe(true);
    expect(manager.hasProvider('anthropic')).toBe(false);
  });
  
  test('should send messages to multiple providers', async () => {
    const manager = new LLMManager({
      openai: { apiKey: 'test-openai-key' },
      anthropic: { apiKey: 'test-anthropic-key' },
      gemini: { apiKey: 'test-gemini-key' }
    });
    
    const results = await manager.sendMessage(
      'Test message',
      'test-conversation-id',
      ['openai', 'anthropic']
    );
    
    expect(results.openai).toBeDefined();
    expect(results.anthropic).toBeDefined();
    expect(results.gemini).toBeUndefined();
    
    expect(results.openai.content).toBe('Test response from OpenAI');
    expect(results.anthropic.content).toBe('Test response from Claude');
  });
  
  test('should handle provider errors gracefully', async () => {
    // Make OpenAI provider throw an error
    (OpenAIProvider as jest.Mock).mockImplementation(() => ({
      sendMessage: jest.fn().mockRejectedValue(new Error('API key error'))
    }));
    
    const manager = new LLMManager({
      openai: { apiKey: 'test-openai-key' },
      anthropic: { apiKey: 'test-anthropic-key' }
    });
    
    const results = await manager.sendMessage(
      'Test message',
      'test-conversation-id',
      ['openai', 'anthropic']
    );
    
    expect(results.openai.error).toBe('API key error');
    expect(results.anthropic.content).toBe('Test response from Claude');
  });
});
