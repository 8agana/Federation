/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        openai: {
          100: '#E6F7E6',
          500: '#10A37F',
        },
        anthropic: {
          100: '#F3E8FF',
          500: '#7B2CBF',
        },
        gemini: {
          100: '#E6F0FF',
          500: '#1A73E8',
        },
      },
    },
  },
  plugins: [],
}
