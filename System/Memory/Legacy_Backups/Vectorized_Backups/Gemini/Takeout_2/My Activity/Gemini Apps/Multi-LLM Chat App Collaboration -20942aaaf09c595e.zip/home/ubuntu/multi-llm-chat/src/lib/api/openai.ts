import { LLMProvider, LLMResponse, Model, UsageMetrics, LLMConfig } from './types';

export class OpenAIProvider implements LLMProvider {
  private apiKey: string;
  private maxTokens: number;
  private temperature: number;
  
  constructor(config: LLMConfig) {
    this.apiKey = config.apiKey;
    this.maxTokens = config.maxTokens || 1000;
    this.temperature = config.temperature || 0.7;
  }
  
  async sendMessage(message: string, conversationId: string): Promise<LLMResponse> {
    try {
      // In a real implementation, we would fetch the conversation history
      // For now, we'll just use the current message
      
      const response = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${this.apiKey}`
        },
        body: JSON.stringify({
          model: 'gpt-4o',
          messages: [
            { role: 'user', content: message }
          ],
          max_tokens: this.maxTokens,
          temperature: this.temperature
        })
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`OpenAI API error: ${errorData.error?.message || response.statusText}`);
      }
      
      const data = await response.json();
      
      return {
        id: data.id,
        content: data.choices[0].message.content,
        model: data.model,
        provider: 'openai',
        usage: {
          promptTokens: data.usage.prompt_tokens,
          completionTokens: data.usage.completion_tokens,
          totalTokens: data.usage.total_tokens
        }
      };
    } catch (error) {
      console.error('Error calling OpenAI API:', error);
      throw error;
    }
  }
  
  async getModels(): Promise<Model[]> {
    try {
      const response = await fetch('https://api.openai.com/v1/models', {
        headers: {
          'Authorization': `Bearer ${this.apiKey}`
        }
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`OpenAI API error: ${errorData.error?.message || response.statusText}`);
      }
      
      const data = await response.json();
      
      // Filter for chat models only
      const chatModels = data.data
        .filter((model: any) => model.id.includes('gpt'))
        .map((model: any) => ({
          id: model.id,
          name: model.id,
          provider: 'openai',
          capabilities: ['text']
        }));
      
      return chatModels;
    } catch (error) {
      console.error('Error fetching OpenAI models:', error);
      return [
        {
          id: 'gpt-4o',
          name: 'GPT-4o',
          provider: 'openai',
          capabilities: ['text']
        },
        {
          id: 'gpt-4-turbo',
          name: 'GPT-4 Turbo',
          provider: 'openai',
          capabilities: ['text']
        },
        {
          id: 'gpt-3.5-turbo',
          name: 'GPT-3.5 Turbo',
          provider: 'openai',
          capabilities: ['text']
        }
      ];
    }
  }
  
  async getUsage(): Promise<UsageMetrics> {
    // In a real implementation, we would fetch usage data from the OpenAI API
    // For now, we'll return mock data
    return {
      totalTokens: 0,
      totalCost: 0,
      breakdown: {
        'openai': {
          tokens: 0,
          cost: 0
        }
      }
    };
  }
}
