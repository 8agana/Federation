import { OpenAIProvider } from './openai';
import { AnthropicProvider } from './anthropic';
import { GeminiProvider } from './gemini';
import { LLMProvider, LLMConfig } from './types';

// Factory function to create LLM providers
export function createLLMProvider(
  provider: 'openai' | 'anthropic' | 'gemini',
  config: LLMConfig
): LLMProvider {
  switch (provider) {
    case 'openai':
      return new OpenAIProvider(config);
    case 'anthropic':
      return new AnthropicProvider(config);
    case 'gemini':
      return new GeminiProvider(config);
    default:
      throw new Error(`Unsupported provider: ${provider}`);
  }
}

// Class to manage multiple LLM providers
export class LLMManager {
  private providers: Map<string, LLMProvider> = new Map();
  
  constructor(configs?: Record<string, LLMConfig>) {
    if (configs) {
      this.initializeProviders(configs);
    }
  }
  
  initializeProviders(configs: Record<string, LLMConfig>): void {
    for (const [provider, config] of Object.entries(configs)) {
      if (config.apiKey) {
        this.addProvider(provider as 'openai' | 'anthropic' | 'gemini', config);
      }
    }
  }
  
  addProvider(provider: 'openai' | 'anthropic' | 'gemini', config: LLMConfig): void {
    this.providers.set(provider, createLLMProvider(provider, config));
  }
  
  getProvider(provider: string): LLMProvider | undefined {
    return this.providers.get(provider);
  }
  
  hasProvider(provider: string): boolean {
    return this.providers.has(provider);
  }
  
  async sendMessage(
    message: string,
    conversationId: string,
    providers: ('openai' | 'anthropic' | 'gemini')[]
  ): Promise<Record<string, any>> {
    const results: Record<string, any> = {};
    const promises = [];
    
    for (const provider of providers) {
      const llmProvider = this.getProvider(provider);
      if (llmProvider) {
        promises.push(
          llmProvider.sendMessage(message, conversationId)
            .then(response => {
              results[provider] = response;
            })
            .catch(error => {
              results[provider] = { error: error.message };
            })
        );
      }
    }
    
    await Promise.all(promises);
    return results;
  }
}
