# Multi-LLM Chat Application

A Next.js application that allows users to chat with multiple LLM models (OpenAI/ChatGPT, Anthropic/Claude, and Google/Gemini) in a single interface.

## Features

- Chat with multiple AI models simultaneously
- Compare responses from different LLMs side-by-side
- Manage conversation history
- Set usage limits for each model
- Secure API key management

## Technology Stack

- **Frontend**: Next.js with React and Tailwind CSS
- **Backend**: Next.js API routes with Cloudflare Workers
- **Database**: Cloudflare D1 (SQLite at the edge)
- **Deployment**: Cloudflare Pages

## Getting Started

### Prerequisites

- Node.js 18+ and npm
- API keys for the LLM providers you want to use:
  - OpenAI API key
  - Anthropic API key
  - Google Gemini API key

### Installation

1. Clone the repository
   ```bash
   git clone https://github.com/yourusername/multi-llm-chat.git
   cd multi-llm-chat
   ```

2. Install dependencies
   ```bash
   npm install
   ```

3. Run the development server
   ```bash
   npm run dev
   ```

4. Open [http://localhost:3000](http://localhost:3000) in your browser

## Usage

1. Navigate to the Settings page and enter your API keys
2. Select which AI models you want to include in your conversation
3. Start a new conversation
4. Type your message and see responses from all selected models

## Deployment

See [DEPLOYMENT.md](DEPLOYMENT.md) for detailed deployment instructions.

## Testing

Run the test suite with:
```bash
npm test
```

## Project Structure

- `src/app` - Next.js pages and API routes
- `src/components` - React components
- `src/hooks` - Custom React hooks
- `src/lib/api` - LLM provider adapters and API utilities
- `src/tests` - Test files
- `migrations` - Database migration files

## Security Considerations

- API keys are stored in the browser's localStorage
- Keys are only sent to the respective LLM providers when making API calls
- No conversation data is stored on our servers unless explicitly enabled

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgments

- OpenAI for the ChatGPT API
- Anthropic for the Claude API
- Google for the Gemini API
