import { NextRequest, NextResponse } from 'next/server';
import { LLMManager } from '@/lib/api';

// Mock the LLMManager class
jest.mock('@/lib/api', () => ({
  LLMManager: jest.fn().mockImplementation(() => ({
    initializeProviders: jest.fn(),
    addProvider: jest.fn(),
    getProvider: jest.fn(),
    hasProvider: jest.fn().mockImplementation((provider) => true),
    sendMessage: jest.fn().mockImplementation(async (message, conversationId, providers) => {
      const results = {};
      for (const provider of providers) {
        results[provider] = {
          id: `${provider}-test-id`,
          content: `Test response from ${provider}`,
          model: `${provider}-model`,
          provider,
          usage: {
            promptTokens: 10,
            completionTokens: 20,
            totalTokens: 30
          }
        };
      }
      return results;
    })
  }))
}));

// Import the route handler after mocking dependencies
import { POST } from '@/app/api/chat/route';

describe('Chat API Route', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });
  
  test('should return 400 if message is missing', async () => {
    const request = new NextRequest('http://localhost:3000/api/chat', {
      method: 'POST',
      body: JSON.stringify({
        conversationId: 'test-conversation',
        providers: ['openai']
      })
    });
    
    const response = await POST(request);
    const data = await response.json();
    
    expect(response.status).toBe(400);
    expect(data.error).toBe('Message is required');
  });
  
  test('should return 400 if conversationId is missing', async () => {
    const request = new NextRequest('http://localhost:3000/api/chat', {
      method: 'POST',
      body: JSON.stringify({
        message: 'Test message',
        providers: ['openai']
      })
    });
    
    const response = await POST(request);
    const data = await response.json();
    
    expect(response.status).toBe(400);
    expect(data.error).toBe('Conversation ID is required');
  });
  
  test('should return 400 if providers array is empty', async () => {
    const request = new NextRequest('http://localhost:3000/api/chat', {
      method: 'POST',
      body: JSON.stringify({
        message: 'Test message',
        conversationId: 'test-conversation',
        providers: []
      })
    });
    
    const response = await POST(request);
    const data = await response.json();
    
    expect(response.status).toBe(400);
    expect(data.error).toBe('At least one provider is required');
  });
  
  test('should process chat request successfully', async () => {
    const request = new NextRequest('http://localhost:3000/api/chat', {
      method: 'POST',
      body: JSON.stringify({
        message: 'Test message',
        conversationId: 'test-conversation',
        providers: ['openai', 'anthropic', 'gemini'],
        apiKeys: {
          openai: 'test-openai-key',
          anthropic: 'test-anthropic-key',
          gemini: 'test-gemini-key'
        }
      })
    });
    
    const response = await POST(request);
    const data = await response.json();
    
    expect(response.status).toBe(200);
    expect(data.results).toBeDefined();
    expect(data.results.openai).toBeDefined();
    expect(data.results.anthropic).toBeDefined();
    expect(data.results.gemini).toBeDefined();
    
    // Check response content
    expect(data.results.openai.content).toBe('Test response from openai');
    expect(data.results.anthropic.content).toBe('Test response from anthropic');
    expect(data.results.gemini.content).toBe('Test response from gemini');
  });
});
