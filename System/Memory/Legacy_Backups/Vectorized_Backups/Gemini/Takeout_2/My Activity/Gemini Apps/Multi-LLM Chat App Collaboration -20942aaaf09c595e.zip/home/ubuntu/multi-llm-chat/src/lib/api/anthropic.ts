import { LLMProvider, LLMResponse, Model, UsageMetrics, LLMConfig } from './types';

export class AnthropicProvider implements LLMProvider {
  private apiKey: string;
  private maxTokens: number;
  private temperature: number;
  
  constructor(config: LLMConfig) {
    this.apiKey = config.apiKey;
    this.maxTokens = config.maxTokens || 1000;
    this.temperature = config.temperature || 0.7;
  }
  
  async sendMessage(message: string, conversationId: string): Promise<LLMResponse> {
    try {
      // In a real implementation, we would fetch the conversation history
      // For now, we'll just use the current message
      
      const response = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': this.apiKey,
          'anthropic-version': '2023-06-01'
        },
        body: JSON.stringify({
          model: 'claude-3-7-sonnet-20240229',
          max_tokens: this.maxTokens,
          temperature: this.temperature,
          messages: [
            { role: 'user', content: message }
          ]
        })
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(`Anthropic API error: ${errorData.error?.message || response.statusText}`);
      }
      
      const data = await response.json();
      
      return {
        id: data.id,
        content: data.content[0].text,
        model: data.model,
        provider: 'anthropic',
        usage: {
          promptTokens: data.usage.input_tokens,
          completionTokens: data.usage.output_tokens,
          totalTokens: data.usage.input_tokens + data.usage.output_tokens
        }
      };
    } catch (error) {
      console.error('Error calling Anthropic API:', error);
      throw error;
    }
  }
  
  async getModels(): Promise<Model[]> {
    // Anthropic doesn't have a models endpoint, so we'll return a static list
    return [
      {
        id: 'claude-3-7-sonnet-20240229',
        name: 'Claude 3.7 Sonnet',
        provider: 'anthropic',
        capabilities: ['text']
      },
      {
        id: 'claude-3-5-sonnet-20240620',
        name: 'Claude 3.5 Sonnet',
        provider: 'anthropic',
        capabilities: ['text']
      },
      {
        id: 'claude-3-opus-20240229',
        name: 'Claude 3 Opus',
        provider: 'anthropic',
        capabilities: ['text']
      }
    ];
  }
  
  async getUsage(): Promise<UsageMetrics> {
    // In a real implementation, we would track usage data
    // For now, we'll return mock data
    return {
      totalTokens: 0,
      totalCost: 0,
      breakdown: {
        'anthropic': {
          tokens: 0,
          cost: 0
        }
      }
    };
  }
}
