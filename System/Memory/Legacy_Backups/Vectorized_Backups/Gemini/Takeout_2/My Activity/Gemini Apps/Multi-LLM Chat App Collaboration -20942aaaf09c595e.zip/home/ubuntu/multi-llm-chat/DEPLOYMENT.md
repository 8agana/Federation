# Multi-LLM Chat Application Deployment Guide

This guide explains how to deploy the Multi-LLM Chat application using Cloudflare Workers.

## Prerequisites

1. A Cloudflare account
2. Node.js and npm installed
3. Wrangler CLI installed (`npm install -g wrangler`)
4. API keys for the LLM providers you want to use:
   - OpenAI API key
   - Anthropic API key
   - Google Gemini API key

## Deployment Steps

1. **Login to Cloudflare**

   ```bash
   wrangler login
   ```

2. **Configure Wrangler**

   The project already includes a `wrangler.toml` file with the necessary configuration.

3. **Initialize the Database**

   ```bash
   wrangler d1 execute DB --local --file=migrations/0001_initial.sql
   wrangler d1 migrations apply DB --local
   ```

4. **Deploy the Application**

   ```bash
   wrangler deploy
   ```

5. **Set Environment Variables**

   While we don't store API keys in the application (they're provided by users), you can set default keys for testing:

   ```bash
   wrangler secret put OPENAI_API_KEY
   wrangler secret put ANTHROPIC_API_KEY
   wrangler secret put GEMINI_API_KEY
   ```

## Local Development

1. **Start the Development Server**

   ```bash
   npm run dev
   ```

2. **Run Tests**

   ```bash
   npm test
   ```

## Usage Instructions

1. Open the deployed application URL
2. Navigate to Settings and enter your API keys for the LLM providers
3. Select which models you want to include in your conversation
4. Start chatting!

## Security Considerations

- API keys are stored in the browser's localStorage and are never sent to our servers except when making API calls
- All API requests are made directly from the client to the LLM providers
- No conversation data is stored on our servers unless you explicitly enable the conversation history feature

## Troubleshooting

- If you encounter CORS errors, make sure your Cloudflare Workers configuration allows requests from your domain
- If API calls fail, verify that your API keys are correct and have sufficient permissions
- For other issues, check the browser console for error messages
