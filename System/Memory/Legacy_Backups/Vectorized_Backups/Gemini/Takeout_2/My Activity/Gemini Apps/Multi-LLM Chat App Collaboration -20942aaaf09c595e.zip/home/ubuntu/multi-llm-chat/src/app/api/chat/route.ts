import { NextRequest, NextResponse } from 'next/server';
import { LLMManager } from '@/lib/api';

// Create a singleton instance of LLMManager
let llmManager: LLMManager | null = null;

// Initialize the LLM manager with API keys from environment variables
function getLLMManager() {
  if (!llmManager) {
    llmManager = new LLMManager();
  }
  return llmManager;
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { message, conversationId, providers, apiKeys } = body;
    
    if (!message) {
      return NextResponse.json(
        { error: 'Message is required' },
        { status: 400 }
      );
    }
    
    if (!conversationId) {
      return NextResponse.json(
        { error: 'Conversation ID is required' },
        { status: 400 }
      );
    }
    
    if (!providers || !Array.isArray(providers) || providers.length === 0) {
      return NextResponse.json(
        { error: 'At least one provider is required' },
        { status: 400 }
      );
    }
    
    // Initialize LLM manager with API keys
    const manager = getLLMManager();
    
    // Add providers with API keys
    if (apiKeys) {
      for (const [provider, apiKey] of Object.entries(apiKeys)) {
        if (apiKey && ['openai', 'anthropic', 'gemini'].includes(provider)) {
          manager.addProvider(provider as 'openai' | 'anthropic' | 'gemini', { apiKey: apiKey as string });
        }
      }
    }
    
    // Check if requested providers are available
    const availableProviders = providers.filter(provider => 
      manager.hasProvider(provider)
    );
    
    if (availableProviders.length === 0) {
      return NextResponse.json(
        { error: 'None of the requested providers are available. Please check your API keys.' },
        { status: 400 }
      );
    }
    
    // Send message to all requested providers
    const results = await manager.sendMessage(
      message,
      conversationId,
      availableProviders as ('openai' | 'anthropic' | 'gemini')[]
    );
    
    return NextResponse.json({ results });
  } catch (error) {
    console.error('Error processing chat request:', error);
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
